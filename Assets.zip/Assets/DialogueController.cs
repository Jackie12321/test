using TMPro;
using UnityEngine;
using UnityEngine.UI;

//component of DialogueController, we need this to show the portrait of npc, name and what dialogue shows up,
//we also have a choices button to check which option the user has inputted and clone prefabs depending on amount of choices
public class DialogueController : MonoBehaviour
{
    public static DialogueController Instance { get; private set; } //singleton instance can call from anywhere only one instance

    public GameObject dialoguePanel;
    public TMP_Text dialogueText, nameText;
    public Image portraitImage;

    //dynamically clone from prefabs folder choices, for e.g) we can have Yes, No, Maybe choices cloned onto environment
    public Transform choiceContainer;
    public GameObject choiceButtonPrefab;
    

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void ShowDialogueUI(bool show)
    {
        dialoguePanel.SetActive(show); //visibility
    }

    public void SetNPCInfo(string npcName, Sprite portrait)
    {
        nameText.text = npcName;
        portraitImage.sprite = portrait;
    }

    public void SetDialogueText(string text)
    {
        dialogueText.text = text;
    }

    public void ClearChoices()
    {
        foreach (Transform child in choiceContainer) Destroy(child.gameObject);
    }

    public GameObject CreateChoiceButton(string choiceText, UnityEngine.Events.UnityAction onClick)
    {
        GameObject choiceButton = Instantiate(choiceButtonPrefab, choiceContainer); //new version of prefab in our choice panel
        choiceButton.GetComponentInChildren<TMP_Text>().text = choiceText;
        choiceButton.GetComponent<Button>().onClick.AddListener(onClick);

        return choiceButton;
    }

}
