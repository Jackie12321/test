﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class SPUM_EyeSet : MonoBehaviour
{
    public List<SpriteRenderer> _SpList = new List<SpriteRenderer>();
}
