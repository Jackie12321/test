using UnityEngine;
using UnityEngine.UI;

public class SPUM_PackageElement : MonoBehaviour
{
    public Text AnimName;
    public Button PlayButton;
    public Toggle SelectButton;
}