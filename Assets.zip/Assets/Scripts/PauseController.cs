using UnityEngine;
//singleton, call this whenever game needs to be paused so other actions can't be done
public class PauseController : MonoBehaviour
{
    public static bool IsGamePaused { get; private set; } = false;
    public static void SetPause(bool pause)
    {
        IsGamePaused = pause;
    }
}
