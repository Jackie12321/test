using UnityEngine;

public class Player : MonoBehaviour
{
    public PlayerMovement playerMovement { get; private set; }
    private PlayerStateMachine playerStateMachine;

    public IdleState idleState { get; private set; }
    public MoveState moveState { get; private set; }
    public SwordAttackState swordAttackState { get; private set; }
    public BowAttackState bowAttackState { get; private set; }

    private void Awake()
    {
        playerMovement = GetComponent<PlayerMovement>();
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerStateMachine = new PlayerStateMachine(GetComponentInChildren<Animator>());

        idleState = new IdleState(this, playerStateMachine, "Idle");
        moveState = new MoveState(this, playerStateMachine, "Move");
        swordAttackState = new SwordAttackState(this, playerStateMachine, "SwordAttack");
        bowAttackState = new BowAttackState(this, playerStateMachine, "BowAttack");

        playerStateMachine.ChangeState(idleState);
    }

    // Update is called once per frame
    void Update()
    {
        if (PauseController.IsGamePaused) return;
        playerStateMachine.Update();
    }

    public void ReturnToIdle()
    {
        playerStateMachine.ChangeState(idleState);
    }
}
