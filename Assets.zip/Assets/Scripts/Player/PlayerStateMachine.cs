using UnityEngine;

public class PlayerStateMachine
{
    [SerializeField] private Animator animator;
    private State currentState;

    public Animator playerAnimator
    {
        get => animator;
    }

    public PlayerStateMachine(Animator animator)
    {
        this.animator = animator;
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    public void Update()
    {
        currentState?.Update();
    }

    // Method to change the current state
    public void ChangeState(State newState)
    {
        // Exit the current state
        currentState?.Exit();

        // Enter the new state
        currentState = newState;
        currentState.Enter();
    }
}
