using UnityEngine;

public class BusylessState : State
{
    public BusylessState(Player player, PlayerStateMachine playerStateMachine, string animBoolName) : base(player, playerStateMachine, animBoolName)
    {
    }

    public override void Update()
    {
        base.Update();

        // Check for actions here like attacking, jumping, etc.

        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            playerStateMachine.ChangeState(player.swordAttackState);
        }

        else if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            playerStateMachine.ChangeState(player.bowAttackState);
        }
    }
}
