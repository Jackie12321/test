using UnityEngine;

public class IdleState : BusylessState
{
    public IdleState(Player player, PlayerStateMachine playerStateMachine, string animBoolName) : base(player, playerStateMachine, animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
        player.playerMovement.Move(new Vector2(0, 0));
    }

    public override void Update()
    {
        if(Input.GetAxis("Horizontal") != 0 || Input.GetAxis("Vertical") != 0)
        {
            playerStateMachine.ChangeState(player.moveState);
            return;
        }

        base.Update();
    }

    public override void Exit()
    {
        base.Exit();
    }
}
