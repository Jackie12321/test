using UnityEngine;

public class MoveState : BusylessState
{
    public MoveState(Player player, PlayerStateMachine playerStateMachine, string animBoolName) : base(player, playerStateMachine, animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Update()
    {

        player.playerMovement.Move(new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical")));

        if (Input.GetAxis("Horizontal") == 0 && Input.GetAxis("Vertical") == 0)
        {
            playerStateMachine.ChangeState(player.idleState);
            return;
        }

        base.Update();
    }

    public override void Exit()
    {
        base.Exit();
    }
}
