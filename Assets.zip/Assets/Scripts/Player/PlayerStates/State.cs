using UnityEngine;

public class State
{
    protected Player player;
    protected PlayerStateMachine playerStateMachine;
    protected string animBoolName;

    public State(Player player, PlayerStateMachine playerStateMachine, string animBoolName)
    {
        this.player = player;
        this.playerStateMachine = playerStateMachine;
        this.animBoolName = animBoolName;
    }

    public virtual void Enter()
    {
        // Code to execute when entering the state
        if (animBoolName != "")
            playerStateMachine.playerAnimator.SetBool(animBoolName, true);
    }

    public virtual void Update()
    {
        // Code to execute every frame while in the state
    }

    public virtual void Exit()
    {
        // Code to execute when exiting the state
        if (animBoolName != "")
            playerStateMachine.playerAnimator.SetBool(animBoolName, false);
    }
}
