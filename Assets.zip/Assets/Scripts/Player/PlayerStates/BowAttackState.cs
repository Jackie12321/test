using UnityEngine;

public class BowAttackState : State
{
    public BowAttackState(Player player, PlayerStateMachine playerStateMachine, string animBoolName) : base(player, playerStateMachine, animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
        player.playerMovement.Move(new Vector2(0, 0));
    }

    public override void Exit()
    {
        base.Exit();
        // Add code to handle exiting the bow attack state
    }

    public override void Update()
    {
        base.Update();
    }
}
