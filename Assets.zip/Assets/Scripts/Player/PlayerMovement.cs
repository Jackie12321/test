using Unity.VisualScripting;
using UnityEngine;

[RequireComponent(typeof(Player))]
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMovement: MonoBehaviour
{

    [Header("Movement Info")]
    [SerializeField] private float moveSpeed = 5f;

    private Player player;
    private Rigidbody2D player_rb;
    private Animator animator;

    private void Awake()
    {
        player = GetComponent<Player>();
        player_rb = GetComponent<Rigidbody2D>();
    }

    public void Move(Vector2 direction)
    {
        if (direction.x != 0)
        {
            player.transform.localScale = new Vector3(direction.x > 0 ? -1 : 1, player.transform.localScale.y, player.transform.localScale.z);
        }

        player_rb.linearVelocity = direction.normalized * moveSpeed;
    }

    void Update()
    {
        if (PauseController.IsGamePaused)
        {
            player_rb.linearVelocity = Vector2.zero;
        }
     

    }
}
