using UnityEngine;

public class PlayerAnimTriggers : MonoBehaviour
{
    private Player player;

    private void Awake()
    {
        player = GetComponentInParent<Player>();
    }

    public void ReturnToIdle()
    {
        player.ReturnToIdle();
    }
}
