using UnityEngine;
[CreateAssetMenu(fileName ="NewNPCDialogue", menuName ="NPC Dialogue")]


public class NPCDialog : ScriptableObject
{
    public string npcName;
    public Sprite npcPortrait;
    public string[] dialogueLines;
    public bool[] autoProgressLines;
    public bool[] endDialogueLines; //mark where dialogue ends

    public float autoProgressDelay = 1.5f;
    public float typingSpeed = 0.04f;
    //public AudioClip voiceSound;
    //public float voicePitch = 1f;
    public DialogueChoice[] choices;

    public int questInProgressIndex; //what does npc say while quest in progress
    public int questCompletedIndex; //what does npc say when completed
    public Quest quest; //quest npc gives to player

}

[System.Serializable] //used to enable Unity to save and load data from your custom classes, making them accessible in the Unity editor and persistent between project sessions
public class DialogueChoice
{
    public int dialogueIndex; //choices appear
    public string[] choices; //response options
    public int[] nextDialogueIndexes; //where it leads

    public bool[] givesQuest; //if choice gives quest
}