using UnityEngine;

//enable communication between classes without direct knowledge of each other
//checking if something can be interacted with
public interface IInteractable
{
    void Interact();

    bool CanInteract();
}
