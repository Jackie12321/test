using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

//put this script in any npc/sprite base template allows us to give them dialogue and option for quests
public class NPC : MonoBehaviour, IInteractable
{
    public NPCDialog dialogueData;
    private DialogueController dialogueUI;

    private int dialogueIndex;
    private bool isTyping, isDialogueActive;

    private enum QuestState { NotStarted, InProgress, Completed }
    private QuestState questState = QuestState.NotStarted;

    private void Start()
    {
        dialogueUI = DialogueController.Instance;        
    }

    public QuestConditions.Condition TalkToCondition;




    public bool CanInteract()
    {
        return !isDialogueActive;
    }



    public void Interact()
    {
        QuestConditions.Instance.SetCondition(TalkToCondition);

        if(dialogueData == null || (PauseController.IsGamePaused && !isDialogueActive)) //pausing so dialogue and menu do not overlap
                return;

        if(isDialogueActive)
        {
            NextLine();
        }

        else
        {
            StartDialogue();
        }
    }

    void StartDialogue()
    {
        //sync with quest data questController
        SyncQuestState();
        ProcessNPCTalk();
        //set dialogue line depending on quest state
        if (dialogueData.quest == null)
        {
            // Check all active quests to see if we should react
            foreach (var quest in QuestController.Instance.activateQuests)
            {
                if (QuestController.Instance.IsQuestCompleted(quest.QuestID))
                {
                    // Use completed dialogue if available
                    if (dialogueData.questCompletedIndex >= 0 &&
                        dialogueData.questCompletedIndex < dialogueData.dialogueLines.Length)
                    {
                        dialogueIndex = dialogueData.questCompletedIndex;
                        break;
                    }
                }
                else if (QuestController.Instance.IsQuestActive(quest.QuestID))
                {
                    // Use in-progress dialogue if available
                    if (dialogueData.questInProgressIndex >= 0 &&
                        dialogueData.questInProgressIndex < dialogueData.dialogueLines.Length)
                    {
                        dialogueIndex = dialogueData.questInProgressIndex;
                        break;
                    }
                }
            }
        }
        else // For quest-giver NPCs (your existing logic)
        {
            if (questState == QuestState.Completed)
            {
                if (dialogueData.questCompletedIndex >= 0 &&
                    dialogueData.questCompletedIndex < dialogueData.dialogueLines.Length)
                {
                    dialogueIndex = dialogueData.questCompletedIndex;
                }
            }
            else if (questState == QuestState.InProgress)
            {
                if (dialogueData.questInProgressIndex >= 0 &&
                    dialogueData.questInProgressIndex < dialogueData.dialogueLines.Length)
                {
                    dialogueIndex = dialogueData.questInProgressIndex;
                }
            }
        }

        isDialogueActive = true;

        dialogueUI.SetNPCInfo(dialogueData.npcName, dialogueData.npcPortrait);
        dialogueUI.ShowDialogueUI(true);

        PauseController.SetPause(true);

        DisplayCurrentLine();
    }

    private void SyncQuestState()
    {
        if (dialogueData.quest == null) return;

        string questID = dialogueData.quest.questID;

        if (QuestController.Instance.IsQuestCompleted(questID) || QuestController.Instance.IsQuestHandedIn(questID))
        {
            questState = QuestState.Completed;
        }
        else if (QuestController.Instance.IsQuestActive(questID))
        {
            questState = QuestState.InProgress;
        }
        else
        {
            questState = QuestState.NotStarted;
        }

    }


    void NextLine()
    {
        if (isTyping)
        {
            //skip typing anim
            StopAllCoroutines();
            dialogueUI.SetDialogueText(dialogueData.dialogueLines[dialogueIndex]);
            isTyping = false;
            return;
        }

        //clear choice
        dialogueUI.ClearChoices();

        //check enddialog lines
        if(dialogueData.endDialogueLines.Length > dialogueIndex && dialogueData.endDialogueLines[dialogueIndex])
        {
            EndDialogue();
            return;
        }

        //check if choices and display
        foreach(DialogueChoice dialogueChoice in dialogueData.choices)
        {
            if(dialogueChoice.dialogueIndex == dialogueIndex)
            {
                DisplayChoices(dialogueChoice);
                return;
            }
        }

        if(++dialogueIndex < dialogueData.dialogueLines.Length)
        {
            //if another line skip line there can be errors if two courotines run at the same time
            DisplayCurrentLine();
        }
        else
        {
            EndDialogue();
        }
    }


    //just storing all characters in a string a displaying 1 letter at a time

    IEnumerator TypeLine()
    {
        isTyping = true;
        dialogueUI.SetDialogueText("");

        foreach(char letter in dialogueData.dialogueLines[dialogueIndex])
        {
            dialogueUI.SetDialogueText(dialogueUI.dialogueText.text += letter);
            yield return new WaitForSeconds(dialogueData.typingSpeed);

        }
        isTyping = false;

        if(dialogueData.autoProgressLines.Length > dialogueIndex && dialogueData.autoProgressLines[dialogueIndex])
        {
            yield return new WaitForSeconds(dialogueData.autoProgressDelay);
            NextLine();
        }
    }

    void DisplayChoices(DialogueChoice choice)
    {
        for(int i = 0; i < choice.choices.Length; i++)
        {
            int nextIndex = choice.nextDialogueIndexes[i];
            bool givesQuest = choice.givesQuest[i];
            dialogueUI.CreateChoiceButton(choice.choices[i], () => ChooseOption(nextIndex, givesQuest));
        }
    }

    void ChooseOption(int nextIndex, bool givesQuest)
    {
        if (givesQuest)
        {
            QuestController.Instance.AcceptQuest(dialogueData.quest);
            questState = QuestState.InProgress;
        }
        //alwaysreset dialogue index regardless of choice
        dialogueIndex = nextIndex;
        dialogueUI.ClearChoices();

       
        if (!givesQuest && dialogueData.quest != null)
        {
            //quest state if declining
            questState = QuestState.NotStarted;
        }

        DisplayCurrentLine();
    }

    void DisplayCurrentLine()
    {
        StopAllCoroutines();
        StartCoroutine(TypeLine()); 
    }

    public void EndDialogue()
    {
        if (isDialogueActive)
        {
            //clear any pending choices
            dialogueUI.ClearChoices();

            //dialogue state
            if (dialogueData.quest != null &&
                questState == QuestState.NotStarted)
            {
                // If player declined quest, reset the dialogue index
                dialogueIndex = 0;
            }

            //completion handling
            if (questState == QuestState.Completed &&
                !QuestController.Instance.IsQuestHandedIn(dialogueData.quest.questID))
            {
                HandleQuestCompletion(dialogueData.quest);
            }

           
            StopAllCoroutines();
            isDialogueActive = false;
            dialogueUI.SetDialogueText("");
            dialogueUI.ShowDialogueUI(false);
            PauseController.SetPause(false);
        }
    }

    void HandleQuestCompletion(Quest quest)
    {
        QuestController.Instance.HandInQuest(quest.questID);
    }

    private void ProcessNPCTalk()
    {
        if (dialogueData == null) return;

        foreach (var quest in QuestController.Instance.activateQuests)
        {
            foreach (var objective in quest.objectives)
            {
                // Now using targetNPCID
                if (objective.type == ObjectiveType.TalkNPC &&
                    !string.IsNullOrEmpty(objective.targetNPCID) &&
                    dialogueData.npcID == objective.targetNPCID &&
                    !objective.IsCompleted)
                {
                    QuestController.Instance.CompleteObjective(
                        quest.QuestID,
                        objective.objectiveID
                    );
                    Debug.Log($"Completed TalkNPC objective by talking to {dialogueData.npcID}");
                    return;
                }
            }
        }
    }


}
