using UnityEngine;
using System.Collections.Generic;
using TMPro;

//contents of what quests should have, we are cloning prefabs to make the UI's
//component of QuestUIController

public class QuestUI : MonoBehaviour
{

    public Transform questListContent;
    public GameObject questEntryPrefab;
    public GameObject objectiveTextPrefab;

    //public Quest testQuest;
    //public int testQuestAmount;
    //private List<QuestProgress> testQuests = new();

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        //for(int i = 0; i < testQuestAmount; i++)
        //{
        //    testQuests.Add(new QuestProgress(testQuest));
        //}
        UpdateQuestUI();

    }

    public void UpdateQuestUI()
    {
        foreach (Transform child in questListContent)
        {
            Destroy(child.gameObject);
        }
        foreach(var quest in QuestController.Instance.activateQuests)
        {
            GameObject entry = Instantiate(questEntryPrefab, questListContent);
            TMP_Text questNameText = entry.transform.Find("QuestNameText").GetComponent<TMP_Text>();
            Transform objectiveList = entry.transform.Find("ObjectiveList");

            questNameText.text = quest.quest.name;

            foreach(var objective in quest.objectives)
            {
                GameObject objTextGO = Instantiate(objectiveTextPrefab, objectiveList);
                TMP_Text objText = objTextGO.GetComponent<TMP_Text>();
                objText.text = $"{objective.description} ({objective.currentAmount}/{objective.requiredAmount})"; // collect/defeat 0/10

                if (objective.IsCompleted)
                {
                    // Soft green color with strikethrough
                    if (ColorUtility.TryParseHtmlString("#186b24", out Color completedColor))
                    {
                        objText.color = completedColor;
                    }
                    objText.fontStyle = FontStyles.Strikethrough;
                }
            }
        }
    }
}//talk with ashad, when plays death animation increment by 1
