using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class QuestController : MonoBehaviour
{
    public static QuestController Instance { get; private set; }
    public List<QuestProgress> activateQuests = new();
    private QuestUI questUI;

    public List<string> handinQuestIDs = new();



    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        questUI = Object.FindFirstObjectByType<QuestUI>();

    }

    public void AcceptQuest(Quest quest)
    {
        if (IsQuestActive(quest.questID)) return;

        if (quest.conditions.Any(x => QuestConditions.Instance.GetCondition(x) == false))return;

        activateQuests.Add(new QuestProgress(quest));

        questUI.UpdateQuestUI();
    }

    public bool IsQuestActive(string questID) => activateQuests.Exists(q => q.QuestID == questID);

    public bool IsQuestCompleted(string questID)
    {
        QuestProgress quest = activateQuests.Find(q => q.QuestID == questID);
        return quest != null && quest.objectives.TrueForAll(o => o.IsCompleted);
    }

    public void HandInQuest(string questID)
    {
        QuestProgress quest = activateQuests.Find(q => q.QuestID == questID);
        if (quest != null)
        {
            handinQuestIDs.Add(questID);
            activateQuests.Remove(quest);
            questUI.UpdateQuestUI();
        }

    }



    public bool IsQuestHandedIn(string questID)
    {
        return handinQuestIDs.Contains(questID);
    }

    public void CompleteObjective(string questID, string objectiveID)
    {
        QuestProgress quest = activateQuests.Find(q => q.QuestID == questID);
        if (quest == null)
        {
            Debug.LogWarning($"Quest {questID} not found in active quests");
            return;
        }

        QuestObjective objective = quest.objectives.Find(o => o.objectiveID == objectiveID);
        if (objective == null)
        {
            Debug.LogWarning($"Objective {objectiveID} not found in quest {questID}");
            return;
        }

        if (!objective.IsCompleted)
        {
            objective.currentAmount = Mathf.Min(objective.currentAmount + 1, objective.requiredAmount);
            questUI.UpdateQuestUI();

            Debug.Log($"Completed objective {objectiveID} in quest {questID}. " +
                     $"Progress: {objective.currentAmount}/{objective.requiredAmount}");

            if (quest.IsCompleted)
            {
                Debug.Log($"Quest {questID} is now complete!");
            }
        }
    }
}
