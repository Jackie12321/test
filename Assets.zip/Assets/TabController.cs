using UnityEngine;
using UnityEngine.UI;

//component of Tabs inside menu UI, each tab is inside an array so we can keep track of the indexing and where the user is at
public class TabController : MonoBehaviour
{

    public Image[] tabImages;
    public GameObject[] pages;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        ActivateTab(0);
    }

    public void ActivateTab(int tabNo)
    {
        for(int i = 0; i < pages.Length; ++i)
        {
            pages[i].SetActive(false);
            tabImages[i].color = Color.gray;
        }
        pages[tabNo].SetActive(true);
        tabImages[tabNo].color = Color.white;
    }
}
