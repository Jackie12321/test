using System.Collections.Generic;
using UnityEngine;

public class QuestConditions : MonoBehaviour
{
    private static QuestConditions _instance;

    //disable interact key or make npc say a different line

    public Dictionary<Condition, bool> conditions = new Dictionary<Condition, bool>()
    {
        { Condition.TalkToJackie, false }, { Condition.TalkToBob, false }, {Condition.TalkToJoe, false }
    };
    
    public static QuestConditions Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindFirstObjectByType<QuestConditions>();
                if (_instance == null)
                {
                    GameObject go = new GameObject("DBManager");
                    _instance = go.AddComponent<QuestConditions>();
                }
            }
            return _instance;
        }
    }

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            _instance = this;
            DontDestroyOnLoad(this.gameObject); // Optional, for persistent singletons
        }
    }

    public void SetCondition(Condition condition)
    {
        conditions[condition] = true;
    }

    public bool GetCondition(Condition condition)
    {
        return conditions.TryGetValue(condition, out bool value) && value;

    }

    public enum Condition
    {
        TalkToJackie, TalkToBob, TalkToJoe
    }
}