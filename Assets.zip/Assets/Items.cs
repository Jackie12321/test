using UnityEngine;

//give an item a specific id 0,1,2 ... 

public class Items : MonoBehaviour
{
    public int ID;
}
